# CS214_Homework1

Created and Worked on by:

Abid Azad     aa2177

Rahul Hedge   rah248

Juan Aracena  jja175
